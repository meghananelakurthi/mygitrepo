from django.shortcuts import render
import os
import pickle
from django.conf import settings

# Load the model from the pickle file
model_path = os.path.join(settings.BASE_DIR, 'modelapp/model.pkl')
with open(model_path, 'rb') as model_file:
    model = pickle.load(model_file)

def predict_view(request):
    if request.method == 'POST':
        # Retrieve data from form
        credit_score = request.POST.get('creditScore')
        age = request.POST.get('age')
        tenure = request.POST.get('tenure')
        balance = request.POST.get('balance')
        estimated_salary = request.POST.get('estimatedSalary')

        # Debugging output
        print(f"Credit Score: {credit_score}, Age: {age}, Tenure: {tenure}, Balance: {balance}, Estimated Salary: {estimated_salary}")

        # Check for None values
        if None in [credit_score, age, tenure, balance, estimated_salary]:
            return render(request, 'modelapp/predict.html', {'error': 'All fields are required.'})

        # Convert to float and make prediction
        try:
            prediction = model.predict([[float(credit_score), float(age), float(tenure), float(balance), float(estimated_salary)]])
        except ValueError as e:
            return render(request, 'modelapp/predict.html', {'error': 'Invalid input. Please ensure all inputs are numbers.'})

        return render(request, 'modelapp/result.html', {'prediction': prediction[0]})

    return render(request, 'modelapp/predict.html')
