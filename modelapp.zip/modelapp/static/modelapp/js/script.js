document.addEventListener('DOMContentLoaded', function() {
    // Example JavaScript functionality
    console.log("JavaScript Loaded!");
});
